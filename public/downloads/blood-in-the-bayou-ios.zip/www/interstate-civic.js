'use strict';
(function(){
function bridgeHeight(bridge,x,y){if(Math.abs(x-bridge.x)>78||y<bridge.start||y>bridge.end)return null;return Math.min(1,(y-bridge.start)/200,(bridge.end-y)/200)*64;}
function bridgeSurface(bridges,x,y){let h=null;for(const b of bridges){const v=bridgeHeight(b,x,y);if(v!==null)h=Math.max(h??0,v);}return h;}
function locations(T=32){return {library:{x:100*T,y:151*T,w:280,h:220},metro:{x:100*T,y:142*T,w:280,h:220},entrance:{x:104*T,y:150*T}};}
function roomBlocked(b,x,y,r){return x-r<b.x+4||x+r>b.x+b.w-4||y-r<b.y+4||y+r>b.y+b.h-4;}
if(typeof module!=='undefined')module.exports={bridgeHeight,bridgeSurface,locations,roomBlocked};if(typeof window==='undefined')return;
// Isolated signed-out review reuses the actual civic shell without building the city.
if(window.level29LibraryReview){window.level29LibraryShell=shell;return;}
let underground=false,returnPoint=null,room=null,library=null,metro=null;
const generate=genCity;genCity=function(){const c=generate.apply(this,arguments);if(!c.highway)return c;underground=false;returnPoint=null;room=null;const L=locations(TILE);c.civicLocations=L;c.civicSolids=[];c.interstateBridges=[{name:'BAYOU MEMORIAL BRIDGE',x:c.highway.bounds.left,start:1300,end:2300},{name:'EAST CITY VIADUCT',x:c.highway.bounds.right,start:900,end:1900}];c.interstateSurface=(x,y)=>bridgeSurface(c.interstateBridges,x,y);
 const height=c.heightAt;c.heightAt=(x,y)=>{const h=c.interstateSurface(x,y);return h===null?height(x,y):h;};
 // Separate civic parcels on added land, clear of neighborhood and military base.
 for(const p of [L.library,L.metro]){if(c.buildings.some(b=>b.x<p.x+p.w&&b.x+b.w>p.x&&b.y<p.y+p.h&&b.y+b.h>p.y))throw Error('Civic parcel occupied');for(let yy=Math.floor(p.y/TILE)-1;yy<Math.ceil((p.y+p.h)/TILE)+1;yy++)for(let xx=Math.floor(p.x/TILE)-1;xx<Math.ceil((p.x+p.w)/TILE)+1;xx++)c.g[yy*c.width+xx]=T_LOT;}
 const b=L.library;c.civicSolids.push({x:b.x,y:b.y,w:b.w,h:3},{x:b.x,y:b.y,w:3,h:b.h},{x:b.x+b.w-3,y:b.y,w:3,h:b.h},{x:b.x,y:b.y+b.h-3,w:b.w/2-24,h:3},{x:b.x+b.w/2+24,y:b.y+b.h-3,w:b.w/2-24,h:3});
 for(let yy=148;yy<=160;yy++)for(let xx=96;xx<=98;xx++)c.g[yy*c.width+xx]=T_ROAD;
 c.civicWalks=[{x:99*TILE,y:b.y+b.h+8,w:b.x+b.w/2-99*TILE+16,h:24},{x:99*TILE,y:L.entrance.y-12,w:L.entrance.x-99*TILE+16,h:24}];for(const w of c.civicWalks)for(let yy=Math.floor(w.y/TILE);yy<=Math.floor((w.y+w.h)/TILE);yy++)for(let xx=Math.floor(w.x/TILE);xx<=Math.floor((w.x+w.w)/TILE);xx++)c.g[yy*c.width+xx]=T_WALK;
 // Signed exits retain existing dedicated routes and gain a direct city-core street link.
 c.interstateExits=c.highway.links.map((l,i)=>({...l,number:i+1,name:['DECATUR ST / BAYOU','AIRPORT / TERMINAL RD','MALL / GARDEN BLVD'][i]}));
 const endpoint={x:130.5*TILE,y:88.5*TILE},anchor={x:c.highway.bounds.right,y:endpoint.y};const path=level29CityExtension.route(c,anchor,endpoint,TILE,[],1);if(!path)throw Error('No East Gate interstate exit');for(const p of path)for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const xx=Math.floor(p.x/TILE)+dx,yy=Math.floor(p.y/TILE)+dy;if(!c.buildings.some(b=>xx*TILE>b.x-16&&xx*TILE<b.x+b.w+16&&yy*TILE>b.y-16&&yy*TILE<b.y+b.h+16))c.g[yy*c.width+xx]=T_ROAD;}
 c.interstateExits.push({name:'EAST GATE RD / DEPOT RD',number:4,path,p:endpoint,anchor});c.highway.links.push({name:'EAST GATE RD',path,p:endpoint,anchor});return c;
};
function shell(g,b,base,label,solidList){const D=level29InteriorModels,wall=D.material('#d1c9b8','tile'),floor=D.material('#9fa9a5','tile'),wood=D.material('#6d5542'),metal=D.material('#4a6069','metal');D.box(g,b.w,2,b.h,b.x+b.w/2,base,b.y+b.h/2,floor);D.box(g,b.w,48,3,b.x+b.w/2,base+24,b.y,wall);for(const x of [b.x,b.x+b.w])D.box(g,3,48,b.h,x,base+24,b.y+b.h/2,wall);
 for(const side of [-1,1])D.box(g,b.w/2-24,48,3,b.x+b.w/2+side*(b.w/4+12),base+24,b.y+b.h,wall);D.box(g,48,10,3,b.x+b.w/2,base+43,b.y+b.h,wall);D.box(g,b.w+6,2,b.h+6,b.x+b.w/2,base+50,b.y+b.h/2,wall);addSign(g,label,180,10,b.x+b.w/2,base+44,b.y+b.h+2,'#e8d5a2');
 if(label.includes('LIBRARY')){const detail=level29LibraryInterior.build(THREE,b,base);g.add(detail.root);solidList.push(...detail.solids);for(const [i,r]of detail.plan.shelves.entries())addSign(g,['SCIENCE','HISTORY','FICTION','REFERENCE'][i],12,2,r.x+7,base+27.5,r.y+r.h+.6,'#d9d6c1');addSign(g,'SCIENCE / LOCAL HISTORY',90,4,b.x+b.w/2-70,base+35,b.y+5,'#e8d5a2');addSign(g,'READING LOUNGE',84,4,b.x+b.w/2,base+38,b.y+146,'#e8d5a2');}

 return {D,wall,floor,wood,metal};}
function build(){if(!city?.civicLocations)return;const D=level29InteriorModels,c=city,g=new THREE.Group();g.name='Interstate bridges and civic expansion';cityGroup.add(g);const asphalt=D.material('#343b42','plaster'),concrete=D.material('#9caaa7','plaster'),steel=D.material('#9daeb1','metal',.7);
 for(const w of c.civicWalks||[])D.box(g,w.w,.5,w.h,w.x+w.w/2,.3,w.y+w.h/2,concrete);
 for(const b of c.interstateBridges){for(let y=b.start;y<b.end;y+=20){const h0=bridgeHeight(b,b.x,y),h1=bridgeHeight(b,b.x,y+20),segment=new THREE.Mesh(new THREE.BoxGeometry(156,3,Math.hypot(20,h1-h0)),asphalt);segment.position.set(b.x,(h0+h1)/2-1.5,y+10);segment.rotation.x=-Math.atan2(h1-h0,20);g.add(segment);for(const side of [-1,1])D.box(g,2,5,22,b.x+side*76,(h0+h1)/2+2.5,y+10,steel);if(y%100===0&&h0>20)for(const side of [-1,1])D.box(g,9,h0,9,b.x+side*62,h0/2,y,concrete);}addSign(g,b.name,150,9,b.x,100,(b.start+b.end)/2,'#e9e6c8');}
 for(const e of c.surfaceRoads?[]:c.interstateExits){const p=e.path[Math.min(4,e.path.length-1)];addSign(g,'I-29 · EXIT '+e.number+' → '+e.name,220,14,p.x,45+(c.interstateSurface(p.x,p.y)||0),p.y,'#cce9db');for(const side of [-1,1])D.box(g,2,45,2,p.x+side*100,22.5,p.y,steel);}
 const L=c.civicLocations;library=new THREE.Group();library.name='Greentown Public Library';cityGroup.add(library);shell(library,L.library,0,'GREENTOWN PUBLIC LIBRARY',c.civicSolids);
 metro=new THREE.Group();metro.name='Underground Decatur Station';cityGroup.add(metro);const b=L.metro;room={...b,furniture:[]};shell(metro,b,-96,'DECATUR UNDERGROUND · PLATFORM 1',room.furniture);
 // Train sits beyond a solid platform edge. It is a station display, not a travel menu.
 D.box(metro,b.w-30,1,8,b.x+b.w/2,-94,b.y+54,D.material('#d1b24b'));room.furniture.push({x:b.x+4,y:b.y+4,w:b.w-8,h:48});for(const x of [b.x+70,b.x+210]){D.box(metro,6,40,6,x,-76,b.y+52,concrete);room.furniture.push({x:x-3,y:b.y+49,w:6,h:6});}
 for(const xx of [b.x+20,b.x+b.w-20])D.box(metro,1,1,32,xx,-97,b.y+24,steel);const train=new THREE.Group();train.name='Metro carriage';metro.add(train);D.box(train,210,26,32,b.x+b.w/2,-80,b.y+24,steel);for(let i=0;i<7;i++)D.box(train,19,11,1,b.x+45+i*30,-77,b.y+41,D.material('#355d70','metal'));D.box(train,214,2,34,b.x+b.w/2,-65,b.y+24,D.material('#b6a25b','metal'));addSign(metro,'METRO',130,6,b.x+b.w/2,-66,b.y+42,'#ecddaa');
 for(const x of [b.x+50,b.x+b.w-50]){D.box(metro,32,5,12,x,-92,b.y+130,steel);room.furniture.push({x:x-16,y:b.y+124,w:32,h:12});}addSign(metro,'U / USE · RETURN TO STREET',140,7,b.x+b.w/2,-70,b.y+b.h-20,'#cde4dc');
 const en=L.entrance;D.box(g,44,2,44,en.x,1,en.y,concrete);for(const side of [-1,1])D.box(g,2,20,42,en.x+side*22,10,en.y,steel);addSign(g,'METRO ↓ · U / USE',95,9,en.x,32,en.y,'#c9e6df');
 // New neighborhood trim uses existing yards; keep walking/driving lanes clear.
 for(const [i,h]of c.neighborhood.homes.entries()){const wood=D.material(i%2?'#9c7854':'#698474'),x=h.x+h.w/2,z=h.y+h.h;D.box(g,31,2,20,x,25,z+7,wood);for(const side of [-1,1]){D.box(g,1.2,25,1.2,x+side*14,12.5,z+14,wood);D.ball(g,h.x+(side<0?14:h.w-14),4,h.y+h.h+24,7,4,6,D.material('#50764c'));}D.box(g,10,2,12,h.x+h.w-18,2,z+25,wood);D.box(g,2,10,2,h.x+h.w-18,6,z+25,steel);addSign(g,String(2900+i),18,4,x,31,z+2,'#ebdfbd');}
 metro.visible=false;
}
const buildBase=buildCity;buildCity=function(){buildBase.apply(this,arguments);build();};
const terrain=terrainHeight;terrainHeight=function(x,y){if(underground&&room&&x>=room.x&&x<=room.x+room.w&&y>=room.y&&y<=room.y+room.h)return -96;return terrain.apply(this,arguments);};
const blocked=blockedCircle;blockedCircle=function(x,y,r){if(underground&&moverCtx===player&&room)return roomBlocked(room,x,y,r)||room.furniture.some(b=>hitRect(x,y,r,b));if((city?.interstateBridges||[]).some(b=>y>b.start&&y<b.end&&Math.abs(x-b.x)>76-r&&Math.abs(x-b.x)<83+r))return true;if((city?.civicSolids||[]).some(b=>hitRect(x,y,r,b)))return true;return blocked.apply(this,arguments);};
const service=serviceVenue;serviceVenue=function(){const L=city?.civicLocations;if(L&&player&&!player.car){if(underground&&Math.hypot(player.x-(L.metro.x+L.metro.w/2),player.y-(L.metro.y+L.metro.h-24))<45){underground=false;metro.visible=false;player.x=returnPoint.x;player.y=returnPoint.y;player.vx=player.vy=0;snapCamera();return toast('DECATUR ST · STREET LEVEL');}if(!underground&&Math.hypot(player.x-L.entrance.x,player.y-L.entrance.y)<40){returnPoint={x:player.x,y:player.y};underground=true;metro.visible=true;player.x=L.metro.x+L.metro.w/2;player.y=L.metro.y+L.metro.h-24;player.vx=player.vy=0;snapCamera();return toast('DECATUR UNDERGROUND · PLATFORM 1 · U TO EXIT');}const b=L.library;if(!underground&&player.x>b.x&&player.x<b.x+b.w&&player.y>b.y&&player.y<b.y+b.h)return toast('GREENTOWN PUBLIC LIBRARY · READING ROOM / LOCAL HISTORY');}return service.apply(this,arguments);};
const tick=update;update=function(){tick.apply(this,arguments);if(underground&&(!player||player.dead||player.car)){underground=false;if(metro)metro.visible=false;}if(!city?.civicLocations)return;if(library)library.visible=true;};
const indoor=window.isPlayerInsideBuilding;if(indoor)window.isPlayerInsideBuilding=function(p=player){return underground&&p===player||indoor(p);};
const missionUpdate=updateMission;updateMission=function(){if(!underground)return missionUpdate.apply(this,arguments);};
const blips=extraBlips;extraBlips=function(){const out=blips.apply(this,arguments),L=city?.civicLocations;if(L)out.push({x:L.library.x+L.library.w/2,y:L.library.y+L.library.h,col:'#e8d5a2',label:'L'},{x:L.entrance.x,y:L.entrance.y,col:'#9bddda',label:'U'});return out;};
window.level29InterstateCivic={bridgeHeight,bridgeSurface,locations,build,get underground(){return underground;}};
})();
