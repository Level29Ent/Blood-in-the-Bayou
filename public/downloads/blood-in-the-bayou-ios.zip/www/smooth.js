'use strict';
// =====================================================================
// Smoother controls and frame pacing on desktop and mobile:
//  - desktop: pointer-lock mouse look (no more cursor hitting the screen edge)
//  - mobile: touch look is applied immediately, without a multi-frame tail
//  - adaptive render resolution keeps the frame rate steady on slower devices
//  - inputs are released when the tab loses focus so nothing gets stuck
// =====================================================================
(() => {
  const isTouch = matchMedia('(pointer: coarse)').matches || navigator.maxTouchPoints > 0;
  window.L29_SKIP_IDLE_FRAMES = true;

  const css = document.createElement('style');
  css.textContent = `
    html,body{overscroll-behavior:none;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;-webkit-tap-highlight-color:transparent}
    #gl,#c{touch-action:none}
    body.is-touch button{touch-action:manipulation}
  `;
  document.head.appendChild(css);
  // iOS Safari ignores user-scalable=no, so block pinch and double-tap zoom during play.
  for (const ev of ['gesturestart', 'gesturechange']) document.addEventListener(ev, e => e.preventDefault(), { passive: false });
  let lastTap = 0;
  document.addEventListener('touchend', e => {
    const now = performance.now();
    // Only the game surface needs this: cancelling touchend on a button also cancels its click.
    const onControl = e.target && e.target.closest && e.target.closest('button,a,input,textarea,select,label,[role=button],[data-place]');
    if (now - lastTap < 320 && !onControl) e.preventDefault();
    lastTap = now;
  }, { passive: false });

  // Touch events already arrive at the browser's input cadence. Do not queue
  // camera deltas until render: movement/fire simulation must see current aim.

  // ---------- Desktop pointer lock ----------
  const lockable = !isTouch && 'requestPointerLock' in cv;
  const isLocked = () => document.pointerLockElement === cv;
  const wheelIsOpen = () => { try { return !!wheelOpen; } catch (_) { return false; } };
  let lockHinted = false;
  if (lockable){
    cv.addEventListener('mousedown', e => {
      if (e.button !== 0 || state !== 'play' || isLocked() || wheelIsOpen()) return;
      // The click that captures the mouse shouldn't also fire a shot.
      mouse.down = false;
      try { const p = cv.requestPointerLock({ unadjustedMovement: true }); if (p && p.catch) p.catch(() => { try { cv.requestPointerLock(); } catch (_) {} }); } catch (_) {}
    });
    document.addEventListener('pointerlockchange', () => {
      view.locked = isLocked();
      if (view.locked && !lockHinted){ lockHinted = true; toast('MOUSE LOOK ON · ESC TO RELEASE'); }
    });
  }

  // ---------- Release inputs when focus is lost ----------
  function releaseAll(){
    for (const k in keys) keys[k] = false;
    mouse.down = false;
    for (const k in touch) touch[k] = false;
    stick.x = 0; stick.y = 0;
    gp.fire = gp.sprint = gp.brake = false;
  }
  addEventListener('blur', releaseAll);
  document.addEventListener('visibilitychange', () => { if (document.hidden) releaseAll(); });

  // ---------- Adaptive resolution ----------
  const mobile = isTouch || !!window.level29MobileBudget?.mobile;
  const MIN_RATIO = mobile ? .85 : .5;
  // Follow the runtime pacing target; fallback phones must not chase 60fps.
  const slowMs = mobile ? 38 : 24, fastMs = mobile ? 30 : 18;
  let ratio = 0, avg = 16.7, lastFrame = 0, lastChange = 0, slowFor = 0, fastFor = 0;
  function capRatio(){ if(window.level29MobileBudget)return window.level29MobileBudget.pixelRatio(innerWidth,innerHeight,devicePixelRatio);return mpRole ? Math.min(1, devicePixelRatio || 1) : Math.min(isTouch?1:1.5, devicePixelRatio || 1); }
  function adaptResolution(now, dt){
    if (!renderer || state !== 'play' || document.hidden){slowFor=fastFor=0;avg=1000/(window.level29RuntimePolicy?.budget.fps||60);return;}
    const cap = capRatio();
    ratio = renderer.getPixelRatio();
    const floor = Math.min(MIN_RATIO,cap);
    if (ratio > cap || ratio < floor){ ratio = Math.max(floor,Math.min(cap,ratio)); renderer.setPixelRatio(ratio); }
    avg += (dt - avg) * .05;
    const target=1000/(window.level29RuntimePolicy?.budget.fps||60),slowThreshold=Math.max(slowMs,target*1.3),fastThreshold=Math.max(fastMs,target*1.05);
    if (avg > slowThreshold) { slowFor += dt; fastFor = 0; }
    else if (avg < fastThreshold) { fastFor += dt; slowFor = 0; }
    else { slowFor = fastFor = 0; }
    if (now - lastChange < 2000) return;
    let next = ratio;
    if(mobile&&slowFor>2500&&window.level29Graphics?.quality!=='low')window.level29Graphics.setQuality('low');
    if (slowFor > 1500 && ratio > Math.min(MIN_RATIO,cap)) next = Math.max(Math.min(MIN_RATIO,cap), ratio - .15);
    else if (fastFor > 5000 && ratio < cap) next = Math.min(cap, ratio + .1);
    if (next !== ratio){
      ratio = Math.max(floor,Math.min(cap,Math.round(next * 100) / 100));
      renderer.setPixelRatio(ratio);
      if (typeof MP !== 'undefined') MP.renderScale = capRatio();
      lastChange = now; slowFor = fastFor = 0;
    }
  }

  const prevRender = render;
  render = function(){
    const now = performance.now();
    const elapsed = lastFrame ? now - lastFrame : 16.7;
    const dt = Math.min(200, elapsed);
    lastFrame = now;
    if (lockable && isLocked() && (state !== 'play' || wheelIsOpen())){ try { document.exitPointerLock(); } catch (_) {} }
    if (mobile) window.level29RuntimePolicy?.observeMobileFrame?.(elapsed, state === 'play' && !document.hidden);
    try { adaptResolution(now, dt); } catch (_) {}
    prevRender();
  };

  window.level29Smooth = { get ratio(){ return ratio; }, get avgFrameMs(){ return avg; }, isTouch };
})();
