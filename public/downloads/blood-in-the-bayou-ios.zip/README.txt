Blood in the Bayou - iPhone ads integration

This ZIP includes the current repository game, not the former stale web copy.
It is not an App Store-ready release. Check src/config.json: test ads do not
generate revenue, and testMode is enabled by default.

On a Mac with Node, npm, and Xcode:
1. Unzip to a new folder; do not overwrite an older signed project.
2. Run npm install, then npm run sync in that folder. This is REQUIRED before
   opening Xcode; it installs AdMob and regenerates local Swift package paths.
3. Open ios/App/App.xcodeproj and choose your own Apple signing team.
4. Build on an iPhone and test consent/privacy, mission transitions, no fill,
   dismissal, failure, audio restoration and multiplayer (no ads).
5. Configure AdMob Privacy & messaging and confirm app readiness and policies.

Maintained source and release instructions are in the GitHub repository under
native/ios-app. Do not change only this generated ZIP: update source, set
src/config.json testMode=false ONLY AFTER device/policy verification, and run
pnpm ios:archive from the repository root. A new signed App Store build is still
required. The web site still needs separate AdSense and H5 Games Ads approval.
