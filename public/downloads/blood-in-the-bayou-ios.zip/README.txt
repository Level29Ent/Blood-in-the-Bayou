BLOOD IN THE BAYOU - iOS Xcode project (Capacitor)

On your Mac:
1. Install Xcode from the Mac App Store and open it once.
2. Unzip this folder and open:  ios/App/App.xcodeproj
3. Click "App" in the left sidebar > Signing & Capabilities:
   - Team: pick your Apple Developer team
   - Bundle Identifier: must match the one in App Store Connect
     (App Information page). Default here: com.level29.bloodinthebayou
4. Top bar device menu: choose "Any iOS Device (arm64)".
5. Menu: Product > Archive.
6. When the Organizer opens: Distribute App > App Store Connect > Upload.
7. Wait ~15 min, then pick the build in App Store Connect > Build section.

To update the game later: replace the files in www/ and in ios/App/App/public/
with the new game files, then Archive again with a higher build number
(General tab > Build).
